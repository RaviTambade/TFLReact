const List=()=>{
    return(
        <div>
            <h2>Todays Fresh Flowers</h2>
             <ol>
                <li>Gerbera</li>
                <li>Rose</li>
                <li>Lotus</li>
                <li>Marigold</li>
             </ol>
        </div>
    );
}
export default List;