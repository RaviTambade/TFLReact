
const PieChart =()=>{
    
    return( <div>
                <p>Pie Chart</p>

            </div>);
}

export default PieChart;