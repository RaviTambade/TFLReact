
const LineChart =()=>{
    return( <div>
                <p>Line Chart</p>

            </div>);
}

export default LineChart;