
const BarChart =()=>{
    return( <div>
                <p>Ravi Tambade</p>
            </div>);
}

export default BarChart;