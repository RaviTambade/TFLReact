import './App.css';
import Counter from './Counter';
function App() {
  return (
    <div className="App">
      <h1>My App</h1>
      <Counter />
    </div>
  );
}
export default App;