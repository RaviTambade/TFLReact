import logo from './logo.svg';
import './App.css';
 
import UsersList from './UsersList';
import PostList from './PostList';
import UsersPosts from './usersposts';
function App() {
  return (
    <div className="App">
      <UsersPosts/>
    </div>
  );
}

export default App;

/*
 
 <PostList/>
 <UsersList/>
      <PostList/>


 */
