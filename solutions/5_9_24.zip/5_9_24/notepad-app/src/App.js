import logo from './logo.svg';
import './App.css';
import TextEditor from './TextEditor';
function App() {
  return (
    <div className="App">
      <TextEditor/>
    </div>
  );
}

export default App;
