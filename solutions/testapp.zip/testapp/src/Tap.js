//Class Component

import { Component } from "react";

class Tap extends Component{
    
    
    render(){
            return(
                <div>
                    <h2>TAP</h2>
                    <p>Transflower Acceleration Program</p>
                    <label>Doing ordinary things extra ordinarily</label>
                </div>
            );
    }
}

export default Tap;