 

function Register() {
  return (
    <div>
      <h2>Register</h2>
    </div>
  );
}

export default Register;
