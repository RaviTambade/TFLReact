//Class Component Synatx
import { Component } from "react";

//Employee
//Manager
//Class-----Blue Print
//can number of objects from class
// data members ,
//  properties firstname, lastname
// member function
//   display, show, render------

class Tap extends Component{
    render(){
            //JSX
            return(
                <div>
                    <h2>TAP</h2>
                    <p>Transflower Acceleration Program</p>
                    <label>Doing ordinary things extra ordinarily</label>
                </div>
            );
    }
}

export default Tap;