// function component

function Home() {
  console.log("home invoked....");
    return (
      <div>
         <h2>Transflower Learning</h2>
         <p>Project Based Learning</p>
         <p>Learn by Doing</p>
      </div>
    );
  }
  export default Home;