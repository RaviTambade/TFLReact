
const PieChart =()=>{
    
    return( <div>
                <p>Pie Chart</p>
                <img src="/images/charts/linechart.jpg" width="200" height="200"/>
            </div>);
}

export default PieChart;