
const BarChart =()=>{
    return( <div>
                <p>Ravi Tambade</p>
                <img src="/images/charts/barchart.jpg" width="200" height="200"/>
            </div>);
}

export default BarChart;