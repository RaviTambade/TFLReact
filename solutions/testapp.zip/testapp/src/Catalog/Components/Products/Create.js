// src/components/CreateProduct.js
const Create = () => {
  
  return (
    <div>
      <h1>Create Product</h1>
      
    </div>
  );
};

export default Create;