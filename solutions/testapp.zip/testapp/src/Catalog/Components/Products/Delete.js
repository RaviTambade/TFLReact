
const Delete=()=>{
    return (
        <div>
            <p>Are you sure ?</p>
            <button>Yes</button> | <button>No</button>
        </div>
    );
}

export default Delete;